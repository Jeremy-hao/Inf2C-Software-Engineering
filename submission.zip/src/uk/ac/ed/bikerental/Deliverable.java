package uk.ac.ed.bikerental;

public interface Deliverable {
    public void onPickup();

    public void onDropoff();
}
